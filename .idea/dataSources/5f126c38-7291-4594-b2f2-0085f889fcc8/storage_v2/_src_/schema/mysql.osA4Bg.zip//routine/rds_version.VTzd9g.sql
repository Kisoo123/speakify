create
    definer = rdsadmin@localhost function rds_version() returns varchar(60) deterministic sql security invoker no sql
BEGIN
RETURN '8.0.35.R3';
END;

